CREATE PROCEDURE lodgeSubComplaint @_complaintID int,
                                   @_subComplaintDesc varchar(5000)
AS
DECLARE
    @subComplaintID int;
    SET @subComplaintID = ((SELECT MAX(@subComplaintID)
                            from COMPLAIN where complaintID = @_complaintID) + 1);
    BEGIN TRANSACTION

INSERT INTO COMPLAINT
VALUES (@_complaintID,
        iif(@subComplaintID is null, 1 ,@subComplaintID),
        @_subComplaintDesc,
        0,
        GETDATE(),
        (SELECT DATEADD(day, 2, GETDATE()) AS DateAdd),
        null,
        null,
        (SELECT productID from COMPLAINT where complaintID = @_complaintID and subComplaintID = 0))
UPDATE COMPLAINT
SET status = 0
where complaintID = @_complaintID
    IF @@ROWCOUNT = 0 GOTO errorHandler;

    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

