CREATE procedure getSelectedUserDetails @_username VARCHAR(50)
as
DECLARE @userID int;
SELECT @userID = userID FROM USERS where userEmail=@_username;

    if exists(select 1 from USERS where userEmail = @_username) and
       exists(select 1 from USER_ROLE ur where ur.userID = @userID and ur.[default] = 'true')
        begin
            select * from USERS where userEmail = @_username
            select ur.roleID from USER_ROLE ur where ur.userID = @userID;
            select ur.roleID from USER_ROLE ur where ur.userID = @userID and ur.[default] = 'true';
            return 0;
        end
    else
        begin
            GOTO errorHandler;
        end
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

