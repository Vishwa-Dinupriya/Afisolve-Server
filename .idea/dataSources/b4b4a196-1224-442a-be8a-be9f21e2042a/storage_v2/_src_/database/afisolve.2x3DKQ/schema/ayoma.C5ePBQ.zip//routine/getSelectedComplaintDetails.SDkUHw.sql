CREATE procedure getSelectedComplaintDetails(@_complaintID int,
                                             @_subComplaintID int)
as
    if exists(select 1
              from COMPLAINT
              where complaintID = @_complaintID
                and subComplaintID = @_subComplaintID)
        begin
            select * from COMPLAINT where complaintID = @_complaintID and subComplaintID = @_subComplaintID
            select statusName
            from COMPLAINT_STATUS C_S
                     JOIN COMPLAINT C on C_S.statusID = C.status
            where c.complaintID = @_complaintID
              and c.subComplaintID = @_subComplaintID
            select productName
            from PRODUCT P
                     JOIN COMPLAINT C2 on P.productID = C2.productID
            where C2.complaintID = @_complaintID
              and C2.subComplaintID = @_subComplaintID
            select userEmail, firstName, lastName
            from USERS USR
                     JOIN PRODUCT P2 on USR.userEmail = P2.projectManagerEmail
            where P2.productID = (
                select P.productID
                from PRODUCT P
                         JOIN COMPLAINT C2 on P.productID = C2.productID
                where C2.complaintID = @_complaintID
                  and C2.subComplaintID = @_subComplaintID)
            select userEmail, firstName, lastName
            from USERS USR
                     JOIN PRODUCT P2 on USR.userEmail = P2.accountCoordinatorEmail
            where P2.productID = (
                select P.productID
                from PRODUCT P
                         JOIN COMPLAINT C2 on P.productID = C2.productID
                where C2.complaintID = @_complaintID
                  and C2.subComplaintID = @_subComplaintID)

            return 0;
        end
    else
        begin
            GOTO errorHandler;
        end
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1
go

