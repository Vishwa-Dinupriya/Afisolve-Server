CREATE procedure updateSelectedUserDetails @_oldEmail VARCHAR(50),
                                           @_firstname VARCHAR(40),
                                           @_lastname VARCHAR(40),
                                           @_newEmail VARCHAR(50),
                                           @_password VARCHAR(20),
                                           @_roles roles READONLY,
                                           @_contactNumber VARCHAR(20),
                                           @_defaultRole INT,
                                           @_modifiedAdmin VARCHAR(50)
AS
DECLARE @userID int;
SELECT @userID = userID FROM USERS where userEmail = @_oldEmail;
    BEGIN TRANSACTION

DECLARE
    cursor_email CURSOR FOR SELECT userID, roleID
                            FROM USER_ROLE
                            WHERE userID = @userID
declare @userIDTemp int, @roleID int

    OPEN cursor_email
    fetch next from cursor_email into @userIDTemp, @roleID
    while @@fetch_status = 0
        begin
            delete from USER_ROLE where userID = @userIDTemp AND roleID = @roleID
            fetch next from cursor_email into @userIDTemp, @roleID
        end

UPDATE USERS
SET userEmail    = @_newEmail,
    firstName    = @_firstname,
    lastName     = @_lastname,
    password     = @_password,
    contactNumber= @_contactNumber,
    modifiedBy   = @_modifiedAdmin,
    modifiedAt   = GETDATE()
WHERE userEmail = @_oldEmail;

DECLARE
    role_cursor CURSOR FOR SELECT *
                           FROM @_roles
DECLARE @role INT
    OPEN role_cursor
    FETCH NEXT FROM role_cursor INTO @role
    WHILE @@FETCH_STATUS = 0
        BEGIN
            IF @_defaultRole = null
                BEGIN
                    GOTO errorHandler;
                END
            ELSE
                IF @role = @_defaultRole
                    BEGIN
                        INSERT INTO USER_ROLE VALUES (@userID, @role, 1);
                    END
                ELSE
                    BEGIN
                        INSERT INTO USER_ROLE VALUES (@userID, @role, 0);
                    END

            FETCH NEXT FROM role_cursor INTO @role
        END

    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

