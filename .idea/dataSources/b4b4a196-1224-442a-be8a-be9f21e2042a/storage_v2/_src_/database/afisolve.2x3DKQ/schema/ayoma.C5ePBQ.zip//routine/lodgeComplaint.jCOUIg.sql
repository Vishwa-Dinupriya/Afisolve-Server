CREATE PROCEDURE lodgeComplaint  @_customerEmail varchar(50),
                                 @_productID int,
                                 @_description varchar(5000),
                                 @_noOfImages int
AS
    BEGIN TRANSACTION

DECLARE @currentMaxComplaintID int;
DECLARE @complaintID int;
    SET @currentMaxComplaintID = (SELECT MAX(complaintID) from COMPLAINT) ;
    SET @complaintID = iif(@currentMaxComplaintID is null , 1 , @currentMaxComplaintID+1);

INSERT INTO COMPLAINT
VALUES (@complaintID,
        0,
        @_description,
        0,
        GETDATE(),
        (SELECT DATEADD(day, 2, GETDATE()) AS DateAdd),
        null,
        null,
        @_productID)
    IF @@ROWCOUNT = 0 GOTO errorHandler;

DECLARE @i int;
    SET @i = 0;
    WHILE @i < @_noOfImages
        BEGIN
            SET @i = @i + 1
            /* your code*/
            INSERT INTO COMPLAINT_ATTACHMENT_DETAILS
            VALUES (@complaintID, 0, @i, TRIM(STR(@complaintID)) + '-' + '0' + '-' + TRIM(STR(@i)) + '.png')
        END

SELECT *
FROM COMPLAINT_ATTACHMENT_DETAILS
WHERE complaintID = @complaintID
  and subComplaintID = 0;

    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

