CREATE procedure userLoginDetails @_username VARCHAR(50)
as
    if exists(select 1
              from USERS
              where userEmail = @_username)
        begin
            select firstName from USERS where userEmail = @_username
            select r.roleName
            from ROLE r,
                 USER_ROLE ur
            where ur.userEmail = @_username
              and r.roleID = ur.roleID;
            return 0;
        end
    else
        begin
            return -1;
        end
go

