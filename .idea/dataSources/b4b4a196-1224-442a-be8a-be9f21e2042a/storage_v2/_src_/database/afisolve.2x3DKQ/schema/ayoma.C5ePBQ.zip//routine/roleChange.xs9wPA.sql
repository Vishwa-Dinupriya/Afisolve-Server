CREATE procedure roleChange @_username VARCHAR(50),
                            @_requestedRole VARCHAR(25)
as
    if exists(select 1
              from USER_ROLE ur
                       join ROLE r on r.roleID = ur.roleID
              where ur.userEmail = @_username
                and r.roleName = @_requestedRole)
        begin
            select r.roleName
            from ROLE r
                     join USER_ROLE ur on r.roleID = ur.roleID
            where ur.userEmail = @_username
              and r.roleName = @_requestedRole;
            select userEmail username from USERS where userEmail = @_username;
            return 0;
        end
    else
        begin
            return -1;
        end
go

