CREATE PROCEDURE registerUser @_firstname VARCHAR(40),
                              @_lastname VARCHAR(40),
                              @_email VARCHAR(50),
                              @_password VARCHAR(20),
                              @_roles roles READONLY,
                              @_contactNumber VARCHAR(20),
                              @_defaultRole INT,
                              @_createdAdmin VARCHAR(50)
AS
DECLARE
    @userID int;
    SET @userID = ((SELECT MAX(userID)
                    from USERS) + 1);
    BEGIN TRANSACTION

INSERT INTO USERS
VALUES (iif(@userID is null, 1, @userID), @_email, @_password, @_firstname, @_lastname, @_contactNumber, 'none', null,
        @_createdAdmin, GETDATE(), null,
        null);
    IF @@ROWCOUNT = 0 GOTO errorHandler;

DECLARE
    role_cursor CURSOR FOR SELECT *
                           FROM @_roles
DECLARE @role INT
    OPEN role_cursor
    FETCH NEXT FROM role_cursor INTO @role
    WHILE @@FETCH_STATUS = 0
        BEGIN
            IF @role = @_defaultRole
                BEGIN
                    INSERT INTO USER_ROLE VALUES (iif(@userID is null, 1, @userID), @role, 1);
                END
            ELSE
                BEGIN
                    INSERT INTO USER_ROLE VALUES (iif(@userID is null, 1, @userID), @role, 0);
                END

            FETCH NEXT FROM role_cursor INTO @role
        END


    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

