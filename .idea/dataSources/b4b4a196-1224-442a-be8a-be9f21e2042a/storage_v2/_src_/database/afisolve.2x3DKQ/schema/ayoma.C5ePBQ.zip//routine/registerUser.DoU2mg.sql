CREATE PROCEDURE registerUser @_firstname VARCHAR(40),
                              @_lastname VARCHAR(40),
                              @_email VARCHAR(50),
                              @_password VARCHAR(20),
                              @_roles VARCHAR(25),
                              @_contactNumber VARCHAR(20)
AS
    BEGIN TRANSACTION

INSERT INTO USERS
VALUES (@_email, @_password, @_firstname, @_lastname, @_contactNumber, 'none');
    IF @@ROWCOUNT = 0 GOTO errorHandler;

INSERT INTO USER_ROLE
VALUES (@_email, 3, 1);
    IF @@ROWCOUNT = 0 GOTO errorHandler;

select r.roleName
from ROLE r,
     USER_ROLE ur
where ur.userEmail = @_email
  and r.roleID = ur.roleID;
select userEmail username, firstName, lastName
from USERS
where userEmail = @_email ;


    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

