CREATE procedure login @_email VARCHAR(50),
                       @_password VARCHAR(20)
as
DECLARE @userID int;
SELECT @userID = userID FROM USERS where userEmail = @_email;
    if exists(select 1
              from USERS
              where userEmail = @_email
                and password = @_password)
        begin
            select r.roleName
            from ROLE r,
                 USER_ROLE ur
            where ur.userID = @userID
              and r.roleID = ur.roleID
              and ur.[default] = 1;
            select userEmail username, firstName, lastName from USERS where userEmail = @_email;
            return 0;
        end
    else
        begin
            return -1;
        end
go

