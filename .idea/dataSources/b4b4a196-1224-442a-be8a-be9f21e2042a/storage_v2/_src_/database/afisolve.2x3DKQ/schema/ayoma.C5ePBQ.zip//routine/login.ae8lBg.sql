CREATE procedure login @_email VARCHAR(50),
                       @_password VARCHAR(20)
as
    if exists(select 1
              from USERS
              where userEmail = @_email
                and password = @_password)
        begin
            select r.roleName
            from ROLE r,
                 USER_ROLE ur
            where ur.userEmail = @_email
              and r.roleID = ur.roleID
              and ur.[default] = 1;
            select userEmail username, firstName, lastName from USERS where userEmail = @_email;
            return 0;
        end
    else
        begin
            return -1;
        end
go

