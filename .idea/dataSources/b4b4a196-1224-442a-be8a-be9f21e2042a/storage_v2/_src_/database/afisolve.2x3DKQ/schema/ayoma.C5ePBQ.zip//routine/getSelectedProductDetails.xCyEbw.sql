CREATE procedure getSelectedProductDetails(@_productID int)
as
    if exists(select 1
              from PRODUCT
              where productID = @_productID)
        begin
            select * from PRODUCT where productID = @_productID
            select userEmail, firstName, lastName
            from USERS USR
                     JOIN PRODUCT P1 on USR.userID = P1.customerID
            where P1.productID = @_productID
            select userEmail, firstName, lastName
            from USERS USR
                     JOIN PRODUCT P2 on USR.userID = P2.projectManagerID
            where P2.productID = @_productID
            select userEmail, firstName, lastName
            from USERS USR
                     JOIN PRODUCT P3 on USR.userID = P3.accountCoordinatorID
            where P3.productID = @_productID

            return 0;
        end
    else
        begin
            GOTO errorHandler;
        end
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1
go

