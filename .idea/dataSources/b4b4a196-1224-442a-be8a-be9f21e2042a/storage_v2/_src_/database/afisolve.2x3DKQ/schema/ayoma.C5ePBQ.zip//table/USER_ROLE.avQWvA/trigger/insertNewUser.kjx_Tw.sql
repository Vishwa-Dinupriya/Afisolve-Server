create TRIGGER insertNewUser
    ON USER_ROLE
    after insert
    as
BEGIN
    DECLARE @userEmail varchar(50)

    SELECT @userEmail = inserted.userEmail
    from inserted

    if ((select roleID from inserted where inserted.userEmail = @userEmail) = 0)
        BEGIN
            INSERT INTO CUSTOMER values (@userEmail, null, null)
        END
    if ((select roleID from inserted where inserted.userEmail = @userEmail) = 1)
        BEGIN
            INSERT INTO ACCOUNT_COORDINATOR values (@userEmail, null)
        END
    if ((select roleID from inserted where inserted.userEmail = @userEmail) = 2)
        BEGIN
            INSERT INTO DEVELOPER values (@userEmail, null)
        END
    if ((select roleID from inserted where inserted.userEmail = @userEmail) = 3)
        BEGIN
            INSERT INTO PROJECT_MANAGER values (@userEmail, null)
        END
    if ((select roleID from inserted where inserted.userEmail = @userEmail) = 4)
        BEGIN
            INSERT INTO CEO values (@userEmail)
        END
    if ((select roleID from inserted where inserted.userEmail = @userEmail) = 5)
        BEGIN
            INSERT INTO ADMIN values (@userEmail)
        END
END
go

