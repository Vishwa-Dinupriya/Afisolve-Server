CREATE procedure getSubComplaintsOfSelectedComplain @_complainId VARCHAR(10)
as
    if exists(select 1
              from COMPLAINT c
              where c.complaintID = @_complainId
                and c.subComplaintID != 0)
        begin
            select * from COMPLAINT where subComplaintID != 0 and complaintID = @_complainId
            RETURN 0;
        end
    else
        begin
            --             GOTO errorHandler;
            RETURN 1;
        end
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

