CREATE procedure getCustomerComplaintsByStatusID @_customerEmail VARCHAR(50),
                                                 @_reqComplaintsStatus int
as
DECLARE @customerID int;
SELECT @customerID = userID FROM USERS where userEmail = @_customerEmail;
    if exists(select 1
              from COMPLAINT c)
        begin
            if (@_reqComplaintsStatus = -1)
                BEGIN
                    select *
                    from COMPLAINT C
                             JOIN PRODUCT P ON C.productID = P.productID
                    where C.subComplaintID != 0
                      and P.customerID = @customerID
                    select *
                    from COMPLAINT C
                             JOIN PRODUCT P ON C.productID = P.productID
                    where C.subComplaintID = 0
                      and P.customerID = @customerID
                    RETURN 0;
                END
            else
                if (@_reqComplaintsStatus = 0)
                    BEGIN
                        select *
                        from COMPLAINT C
                                 JOIN PRODUCT P ON C.productID = P.productID
                        where C.subComplaintID != 0
                          and P.customerID = @customerID
                          and C.status = 0
                        select *
                        from COMPLAINT C
                                 JOIN PRODUCT P ON C.productID = P.productID
                        where C.subComplaintID = 0
                          and P.customerID = @customerID
                          and C.status = 0
                        RETURN 0;
                    END
                else
                    if (@_reqComplaintsStatus = 1)
                        BEGIN
                            select *
                            from COMPLAINT C
                                     JOIN PRODUCT P ON C.productID = P.productID
                            where C.subComplaintID != 0
                              and P.customerID = @customerID
                              and C.status = 1
                            select *
                            from COMPLAINT C
                                     JOIN PRODUCT P ON C.productID = P.productID
                            where C.subComplaintID = 0
                              and P.customerID = @customerID
                              and C.status = 1
                            RETURN 0;
                        END
                    else
                        if (@_reqComplaintsStatus = 2)
                            BEGIN
                                select *
                                from COMPLAINT C
                                         JOIN PRODUCT P ON C.productID = P.productID
                                where C.subComplaintID != 0
                                  and P.customerID = @customerID
                                  and C.status = 2
                                select *
                                from COMPLAINT C
                                         JOIN PRODUCT P ON C.productID = P.productID
                                where C.subComplaintID = 0
                                  and P.customerID = @customerID
                                  and C.status = 2
                                RETURN 0;
                            END
                        else
                            if (@_reqComplaintsStatus = 3)
                                BEGIN


                                    select *
                                    from COMPLAINT C
                                             JOIN PRODUCT P ON C.productID = P.productID
                                    where C.subComplaintID != 0
                                      and P.customerID = @customerID
                                      and C.status = 3
                                    select *
                                    from COMPLAINT C
                                             JOIN PRODUCT P ON C.productID = P.productID


                                    where C.subComplaintID = 0
                                      and P.customerID = @customerID
                                      and C.status = 3
                                    RETURN 0;
                                END
        end
    else
        begin
            GOTO errorHandler;
        end
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

