CREATE procedure deleteSelectedProduct @_productID INT
as
    if exists(select 1
              from PRODUCT
              where productID = @_productID)
        begin
            DELETE FROM PRODUCT WHERE productID = @_productID;
        end
    else
        begin
            return -1;
        end
go

