CREATE procedure updateDevTaskStatus (@_taskID INT,@_task_status varchar(20))
AS
    BEGIN TRANSACTION
UPDATE TASK
SET task_status = @_task_status
WHERE taskID = @_taskID;
    IF @@ROWCOUNT = 0 GOTO errorHandler;
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

