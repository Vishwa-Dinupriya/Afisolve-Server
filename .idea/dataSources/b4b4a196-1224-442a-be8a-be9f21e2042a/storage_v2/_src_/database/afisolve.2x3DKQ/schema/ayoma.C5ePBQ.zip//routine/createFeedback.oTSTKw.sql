CREATE PROCEDURE createFeedback @_complaintID int,
                                @_feedback varchar(5000),
                                @_ratedValue int
AS
    BEGIN TRANSACTION

INSERT INTO FEEDBACK
VALUES (@_complaintID,
        @_ratedValue,
        @_feedback)
    IF @@ROWCOUNT = 0 GOTO errorHandler;

UPDATE COMPLAINT
SET status = 3
where complaintID = @_complaintID
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

