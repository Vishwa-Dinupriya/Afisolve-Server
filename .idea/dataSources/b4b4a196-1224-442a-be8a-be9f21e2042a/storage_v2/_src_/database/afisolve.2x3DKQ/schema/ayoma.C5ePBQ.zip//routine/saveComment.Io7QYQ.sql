CREATE PROCEDURE saveComment   @_senderEmail varchar(50),
                               @_complaintID int,
                               @_text varchar(MAX),
                               @_noOfImages int
AS
DECLARE @senderID int;
SELECT @senderID = userID FROM USERS where userEmail = @_senderEmail;
    BEGIN TRANSACTION


DECLARE @currentMaxCommentID int;
DECLARE @commentID int;
    SET @currentMaxCommentID = (SELECT MAX(commentID) from COMMENT where complaintID=@_complaintID) ;
    SET @commentID = iif(@currentMaxCommentID is null , 1 , @currentMaxCommentID+1);
    IF(@_text is not null )
        BEGIN
            INSERT INTO COMMENT
            VALUES (@_complaintID,
                    @commentID,
                    0,
                    @_text,
                    @senderID,
                    GETDATE(),
                    0)
            IF @@ROWCOUNT = 0 GOTO errorHandler;
        end
    SET @currentMaxCommentID = (SELECT MAX(commentID) from COMMENT where complaintID=@_complaintID) ;
    SET @commentID = iif(@currentMaxCommentID is null , 1 , @currentMaxCommentID+1);
DECLARE @i int;
    SET @i = 0;
    WHILE @i < @_noOfImages
        BEGIN
            SET @i = @i + 1
            /* your code*/
            INSERT INTO COMMENT
            VALUES (@_complaintID,@commentID, 1, TRIM(STR(@_complaintID)) + '-' + TRIM(STR(@i)) + '.png',@senderID,GETDATE(),0)
            SELECT * FROM COMMENT where complaintID= @_complaintID and commentID = @commentID
            SET @commentID = @commentID + 1
        END

    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

