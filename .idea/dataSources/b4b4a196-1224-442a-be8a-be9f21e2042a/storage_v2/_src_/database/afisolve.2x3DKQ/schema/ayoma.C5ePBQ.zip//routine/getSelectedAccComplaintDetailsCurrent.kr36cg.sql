CREATE procedure getSelectedAccComplaintDetailsCurrent(@_complaintID int,
                                             @_subComplaintID int)
as
    if exists(select 1
              from COMPLAINT
              where complaintID = @_complaintID
                and subComplaintID = @_subComplaintID)
        begin
           select * from COMPLAINT where complaintID = @_complaintID AND subComplaintID = @_subComplaintID
           select * from Ayoma_ProjectManagers ap,PRODUCT p where ap.userID = p.projectManagerID
            return 0;
        end
    else
        begin
            GOTO errorHandler;
        end
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1
go

