CREATE procedure getSelectedAccComplaintDetailsCurrent(@_complaintID int,
                                             @_subComplaintID int)
as
    if exists(select 1
              from COMPLAINT
              where complaintID = @_complaintID
                and subComplaintID = @_subComplaintID)
        begin
           select * from COMPLAINT where complaintID = @_complaintID AND subComplaintID = @_subComplaintID
           select * from USERS u,PRODUCT p where u.userEmail = p.projectManagerEmail
            return 0;
        end
    else
        begin
            GOTO errorHandler;
        end
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1
go

