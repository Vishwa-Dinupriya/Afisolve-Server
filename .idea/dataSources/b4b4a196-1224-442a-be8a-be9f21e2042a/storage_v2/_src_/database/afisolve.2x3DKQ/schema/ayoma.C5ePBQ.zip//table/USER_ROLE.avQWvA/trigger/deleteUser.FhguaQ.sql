create TRIGGER deleteUser
    ON USER_ROLE
    after delete
    as
BEGIN
    DECLARE @userEmail varchar(50)

    SELECT @userEmail = deleted.userEmail
    from deleted

    if ((select roleID from deleted where deleted.userEmail = @userEmail) = 0)
        BEGIN
            DELETE FROM CUSTOMER where (customerEmail = @userEmail)
        END
    if ((select roleID from deleted where deleted.userEmail = @userEmail) = 1)
        BEGIN
            DELETE FROM ACCOUNT_COORDINATOR where (accountCoordinatorEmail = @userEmail)
        END
    if ((select roleID from deleted where deleted.userEmail = @userEmail) = 2)
        BEGIN
            DELETE FROM DEVELOPER where (developerEmail = @userEmail)
        END
    if ((select roleID from deleted where deleted.userEmail = @userEmail) = 3)
        BEGIN
            DELETE FROM PROJECT_MANAGER where (projectManagerEmail = @userEmail)
        END
    if ((select roleID from deleted where deleted.userEmail = @userEmail) = 4)
        BEGIN
            DELETE FROM CEO where (ceoEmail = @userEmail)
        END
    if ((select roleID from deleted where deleted.userEmail = @userEmail) = 5)
        BEGIN
            DELETE FROM ADMIN where (adminEmail = @userEmail)
        END
END
go

