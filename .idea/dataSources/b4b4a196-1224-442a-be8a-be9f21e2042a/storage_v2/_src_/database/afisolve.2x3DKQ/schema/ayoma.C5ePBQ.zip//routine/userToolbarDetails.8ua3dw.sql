CREATE procedure userToolbarDetails @_username VARCHAR(50)
as
    if exists(select 1
              from USERS
              where userEmail = @_username)
        begin
            select firstName from USERS where userEmail = @_username

            select r.roleName
            from ROLE r,
                 USER_ROLE ur
            where ur.userEmail = @_username
              and r.roleID = ur.roleID;

            select r.roleName defaultRole
            from ROLE r,
                 USER_ROLE ur
            where ur.userEmail = @_username
              and r.roleID = (
                select roleID from USER_ROLE where userEmail = @_username and [default] = 'true'
            );

            return 0;
        end
    else
        begin
            return -1;
        end
go

