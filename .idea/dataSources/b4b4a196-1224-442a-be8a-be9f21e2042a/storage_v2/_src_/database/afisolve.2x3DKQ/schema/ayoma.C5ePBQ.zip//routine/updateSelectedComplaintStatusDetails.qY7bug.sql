CREATE procedure updateSelectedComplaintStatusDetails (@_ID INT, @_subID INT, @_Status varchar(10))
AS
    BEGIN TRANSACTION
UPDATE COMPLAINT
SET status = (select statusID from COMPLAINT_STATUS where statusName = @_Status )
WHERE complaintID = @_ID AND  subComplaintID = @_subID
    IF @@ROWCOUNT = 0 GOTO errorHandler;
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

