CREATE function SelectRole(@role_input varchar)
    Returns int
AS
BEGIN

    if (@role_input = 'Admin')
        begin
            return 0
        end
    if (@role_input = 'Customer')
        begin
            return 5
        end
    if (@role_input = 'Account Coordinator')
        begin
            return 3
        end
    if (@role_input = 'Developer')
        begin
            return 4
        end
    if (@role_input = 'Project Manager')
        begin
            return 2
        end
    if (@role_input = 'CEO')
        begin
            return 1
        end
    return -1
END
go

