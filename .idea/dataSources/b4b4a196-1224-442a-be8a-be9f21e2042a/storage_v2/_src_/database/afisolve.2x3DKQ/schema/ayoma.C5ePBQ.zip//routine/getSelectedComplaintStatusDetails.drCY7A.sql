CREATE procedure getSelectedComplaintStatusDetails (@_complaintID INT,
                                                   @_subComplaintID INT)
as
    if exists(select 1
              from COMPLAINT
              where complaintID = @_complaintID AND subComplaintID = @_subComplaintID)
        begin
            select s.statusName from COMPLAINT c, COMPLAINT_STATUS s where ((c.complaintID = @_complaintID AND c.subComplaintID = @_subComplaintID) AND c.status = s.statusID)
           return 0;
        end
    else
        begin
            GOTO errorHandler;
        end
    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

