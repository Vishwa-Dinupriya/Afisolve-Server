CREATE PROCEDURE registerProduct @_productName varchar(40),
                                 @_category varchar(20),
                                 @_customerEmail varchar(50),
                                 @_projectManagerEmail varchar(50),
                                 @_accountCoordinatorEmail varchar(50),
                                 @_createdAdmin varchar(50)
AS
    BEGIN TRANSACTION
INSERT INTO PRODUCT
VALUES ((Select MAX(productID) FROM PRODUCT) + 1,
        @_productName,
        @_category,
        @_customerEmail,
        @_projectManagerEmail,
        @_accountCoordinatorEmail,
        GETDATE(),
        @_createdAdmin, null, null)
    IF @@ROWCOUNT = 0 GOTO errorHandler;

    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

