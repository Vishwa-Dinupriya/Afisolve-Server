CREATE PROCEDURE registerProduct @_productName varchar(40),
                                 @_category varchar(20),
                                 @_customerEmail varchar(50),
                                 @_projectManagerEmail varchar(50),
                                 @_accountCoordinatorEmail varchar(50),
                                 @_createdAdmin varchar(50)
AS
DECLARE @customerID int;
SELECT @customerID = userID FROM USERS where userEmail = @_customerEmail;

DECLARE @projectManagerID int;
SELECT @projectManagerID = userID FROM USERS where userEmail = @_projectManagerEmail;

DECLARE @accountCoordinatorID int;
SELECT @accountCoordinatorID = userID FROM USERS where userEmail = @_accountCoordinatorEmail;

DECLARE @createdAdminID int;
SELECT @createdAdminID = userID FROM USERS where userEmail = @_createdAdmin;


DECLARE
    @productID int;
    SET @productID = ((SELECT MAX(productID)
                       from PRODUCT) + 1);
    BEGIN TRANSACTION
INSERT INTO PRODUCT
VALUES (iif(@productID is null, 1 ,@productID),
        @_productName,
        @_category,
        @customerID,
        @projectManagerID,
        @accountCoordinatorID,
        GETDATE(),
        @createdAdminID, null, null)
    IF @@ROWCOUNT = 0 GOTO errorHandler;

    COMMIT TRANSACTION;
    RETURN 0;

    errorHandler:
    ROLLBACK TRANSACTION
    RETURN -1;
go

