CREATE procedure deleteSelectedUser @_username VARCHAR(50)
as
    if exists(select 1
              from USERS
              where userEmail = @_username)
        begin
            DECLARE cursor_email CURSOR FOR SELECT userEmail, roleID FROM USER_ROLE WHERE userEmail = @_username

            declare @username varchar(50), @roleID int

            OPEN cursor_email
            fetch next from cursor_email into @username, @roleID

            while @@fetch_status = 0
                begin
                    delete from USER_ROLE where userEmail = @username AND roleID = @roleID
                    fetch next from cursor_email into @username, @roleID
                end

            DELETE FROM USERS WHERE userEmail = @username;
        end
    else
        begin
            return -1;
        end
go

