CREATE procedure deleteSelectedUser @_username VARCHAR(50)
as
DECLARE @userID int;
SELECT @userID = userID FROM USERS where userEmail = @_username;
    if exists(select 1
              from USERS
              where userEmail = @_username)
        begin

            DECLARE cursor_email CURSOR LOCAL FOR SELECT userID, roleID FROM USER_ROLE WHERE userID = @userID

            declare @userIDTemp int, @roleID int

            OPEN cursor_email
            fetch next from cursor_email into @userIDTemp, @roleID

            while @@fetch_status = 0
                begin
                    delete from USER_ROLE where userID = @userIDTemp AND roleID = @roleID
                    fetch next from cursor_email into @userIDTemp, @roleID
                end

            DELETE FROM USERS WHERE userEmail = @_username;
            CLOSE cursor_email
        end
    else
        begin
            return -1;
        end
go

