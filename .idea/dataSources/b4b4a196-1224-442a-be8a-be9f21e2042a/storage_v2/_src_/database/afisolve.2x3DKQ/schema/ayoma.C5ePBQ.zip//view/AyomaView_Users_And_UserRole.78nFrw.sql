create view AyomaView_Users_And_UserRole AS
    select u.userID, u.userEmail, u.firstName, u.lastName, u.contactNumber, u.activeStatus, u.password, ur.roleID, ur.[default], r.roleName
from USERS u, USER_ROLE ur, Role r
where u.userID = ur.userID AND ur.roleID=r.roleID
go

